from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

# UserProfile model to store user's details
class UserProfile(models.Model):
    # Link to Django's built-in User model
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    # Name (optional field for first/last name)
    name = models.CharField(max_length=100, blank=True)  # Optional if you want a separate field

    # Personal Details
    age = models.IntegerField()
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other')
    ]
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    height = models.DecimalField(max_digits=4, decimal_places=1)

    # Job Details
    job_designation = models.CharField(max_length=100)
    job_place = models.CharField(max_length=100)
    education = models.CharField(max_length=100, blank=True, null=True)  # Adding education field


    # Location
    district = models.CharField(max_length=100)

    # Contact details (email handled by the User model)
    mobile_number = models.CharField(max_length=15)

    # Religion and Caste (Dropdown choices)
    RELIGION_CHOICES = [
        ('christian', 'Christian'),
        ('hindu', 'Hindu'),
        ('muslim', 'Muslim'),
        ('other', 'Other')
    ]
    religion = models.CharField(max_length=50, choices=RELIGION_CHOICES)
    
    CASTE_CHOICES = [
        ('general', 'General'),
        ('obc', 'OBC'),
        ('st', 'ST'),
        ('sc', 'SC'),
        ('other', 'Other')
    ]
    caste = models.CharField(max_length=50, choices=CASTE_CHOICES)

    # Marriage Level (Newly Married or Remarriage)
    MARRIAGE_LEVEL_CHOICES = [
        ('single', 'Single'),
        ('married', 'Married'),
        ('divorced', 'Divorced'),
    ]
    marriage_level = models.CharField(max_length=50, choices=MARRIAGE_LEVEL_CHOICES)

    # Family Information
    mother_name = models.CharField(max_length=100)
    father_name = models.CharField(max_length=100)
    mother_job = models.CharField(max_length=100)
    father_job = models.CharField(max_length=100)

    sibling_name = models.CharField(max_length=100, default='Unknown')  # Added default value
    sibling_status = models.CharField(max_length=100, default='Not Specified')  # Added default value

    # # Profile Pictures (store at least 3)
    # profile_picture1 = models.ImageField(upload_to='profile_pics/')
    # profile_picture2 = models.ImageField(upload_to='profile_pics/', null=True, blank=True)
    # profile_picture3 = models.ImageField(upload_to='profile_pics/', null=True, blank=True)

    # User profile approval status (pending or approved)
    status = models.CharField(max_length=20, choices=[('pending', 'Pending'), ('approved', 'Approved')], default='pending')

    # Link user to a package (nullable)
    package = models.ForeignKey('Package', on_delete=models.SET_NULL, null=True, blank=True)

    # Payment status tracking
    has_paid = models.BooleanField(default=False)

    # Expiry date for package access
    expiry_date = models.DateField(null=True, blank=True)

    # Blocked status
    blocked = models.BooleanField(default=False)

    package_active_message_shown = models.BooleanField(default=False)  # Add this line

    blocked_users = models.ManyToManyField("self", symmetrical=False, blank=True)  # Users can block others

    def block_user(self, other_user):
        """Blocks another user."""
        if other_user != self and other_user not in self.blocked_users.all():
            self.blocked_users.add(other_user)
            return True
        return False  # Already blocked or trying to block self
    
    def __str__(self):
        return f'{self.user.username} - {self.marriage_level}'

class ProfilePicture(models.Model):
    user_profile = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='profile_pictures/')

class ProfileVisit(models.Model):
    viewer = models.ForeignKey(User, related_name='profile_views_made', on_delete=models.CASCADE)
    viewed = models.ForeignKey(User, related_name='profile_views_received', on_delete=models.CASCADE)
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.viewer.username} visited {self.viewed.username}"


class Package(models.Model):
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    duration = models.PositiveIntegerField()  # Duration in days
    description = models.TextField(blank=True, null=True)  # Optional description
    image = models.ImageField(upload_to='package_images/', blank=True, null=True)  # Optional image
    expiry_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return self.name


# ChatRequest model to manage chat requests
class ChatRequest(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_requests')
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name='received_requests')
    is_active = models.BooleanField(default=True)
    is_accepted = models.BooleanField(default=False)
    timestamp = models.DateTimeField(auto_now_add=True)
    is_seen = models.BooleanField(default=False)
    status = models.CharField(
        max_length=20,
        choices=[('pending', 'Pending'), ('accepted', 'Accepted'), ('rejected', 'Rejected')],
        default='pending'
    )

    def __str__(self):
        return f"Chat from {self.sender.username} to {self.receiver.username} - {self.status}"


class Message(models.Model):
    chat = models.ForeignKey(ChatRequest, related_name='messages', on_delete=models.CASCADE)
    sender = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Message from {self.sender.username} at {self.timestamp}"

class ContactMessage(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Message from {self.name} ({self.email})"


class SuccessStory(models.Model):
    couple_name = models.CharField(max_length=100)
    email = models.EmailField(blank=True, null=True)
    story = models.TextField()
    photo = models.ImageField(upload_to='success_photos/', blank=True, null=True)
    approved = models.BooleanField(default=False)  # Admin will approve it
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.couple_name
