# In lastapp/admin.py
from django.contrib import admin
from .models import Package

class PackageAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'duration')

admin.site.register(Package, PackageAdmin)
