import string
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import auth, messages
from django.core.mail import send_mail
from django.conf import settings
from .models import UserProfile, Package, ChatRequest, ContactMessage
import os
import random

def home(request):
    return render(request, 'home.html')

from datetime import datetime, timedelta
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth import authenticate, login
# Home view
from django.utils.timezone import now
from datetime import timedelta
from datetime import date

def loginauth(request):
    if request.method == 'POST':
        uname = request.POST.get('uname')
        password = request.POST.get('pwd')
        user = auth.authenticate(username=uname, password=password)

        if user:
            if user.is_staff:
                auth.login(request, user)
                print("Redirecting to admin dashboard")
                return redirect('admin_dashboard')

            user_profile = getattr(user, 'userprofile', None)
            if user_profile:
                if user_profile.status == 'approved':
                    auth.login(request, user)

                    # Debugging output for payment conditions
                    print(f"User has_paid: {user_profile.has_paid}, Expiry Date: {user_profile.expiry_date}")

                    if user_profile.has_paid:
                        if user_profile.expiry_date and user_profile.expiry_date > date.today():
                            # Valid subscription
                            return redirect('user_dashboard')
                        else:
                            # Expired subscription
                            messages.error(request, "Your subscription has expired. Please renew your plan.")
                            return redirect('payment')
                    else:
                        # Never paid
                        return redirect('payment')
                else:
                    messages.error(request, "Your profile has not been approved.")
            else:
                messages.error(request, "No profile found for this user.")
        else:
            messages.error(request, "Invalid username or password.")

        return redirect('login_user')

    return render(request, 'home.html')



def login_user(request):
    # Directly call the authentication logic; no need to call it here
    return render(request, 'login_user.html')


# Logout view
def logout(request):
    auth.logout(request)
    return redirect('home')


from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import get_user_model
from .models import UserProfile, ProfilePicture  # include ProfilePicture
User = get_user_model()  # this is the correct User model


def register(request):
    if request.method == 'POST':
        # Collect form data
        name = request.POST.get('name')
        age = request.POST.get('age')
        gender = request.POST.get('gender')
        height = request.POST.get('height')
        job_designation = request.POST.get('job_designation')
        job_place = request.POST.get('job_place')
        education = request.POST.get('education')
        district = request.POST.get('district')
        email = request.POST.get('email')
        mobile_number = request.POST.get('mobile_number')
        religion = request.POST.get('religion')
        caste = request.POST.get('caste')
        marriage_level = request.POST.get('marriage_level')
        mother_name = request.POST.get('mother_name')
        father_name = request.POST.get('father_name')
        mother_job = request.POST.get('mother_job')
        father_job = request.POST.get('father_job')
        sibling_name = request.POST.get('sibling_name')
        sibling_status = request.POST.get('sibling_status')

        # Check if the email already exists
        if User.objects.filter(email=email).exists():
            return render(request, 'register.html', {
                'existing_email': True,
                'email': email

            })

        # Create User
        user = User.objects.create_user(username=email, email=email)
        user.save()

        # Create UserProfile
        user_profile = UserProfile.objects.create(
            user=user,
            name=name,
            age=age,
            gender=gender,
            height=height,
            job_designation=job_designation,
            job_place=job_place,
            education=education,
            district=district,
            mobile_number=mobile_number,
            religion=religion,
            caste=caste,
            marriage_level=marriage_level,
            mother_name=mother_name,
            father_name=father_name,
            mother_job=mother_job,
            father_job=father_job,
            sibling_name=sibling_name,
            sibling_status=sibling_status,
            status='pending'
        )

        # Save profile pictures (after user_profile is created)
        uploaded_count = 0
        for i in range(1, 9):
            image = request.FILES.get(f'profile_pictures{i}')
            if image:
                ProfilePicture.objects.create(user_profile=user_profile, image=image)
                uploaded_count += 1

        if uploaded_count < 3:
            messages.error(request, "Please upload at least 3 profile pictures.")
            user.delete()
            return redirect('register')

        return render(request, 'register.html', {
            'registration_success': True
        })

    return render(request, 'register.html')



from django.contrib.auth.decorators import login_required
from datetime import datetime
from django.shortcuts import render
from .models import UserProfile

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from datetime import datetime
from .models import UserProfile


@login_required
def admin_dashboard(request):
    # Filter active user profiles: Approved status and expiry date in the future
    active_user_profiles = UserProfile.objects.filter(
        status='approved',
        expiry_date__gte=datetime.now()  # Check for non-expired profiles
    )

    # Filter pending user profiles
    pending_user_profiles = UserProfile.objects.filter(status='pending')

    # Count of active users
    total_active_users = active_user_profiles.count()

    # Count of pending users
    total_pending_users = pending_user_profiles.count()

    # Check if any pending user exists for notification
    notification = pending_user_profiles.exists()

    contact_messages = ContactMessage.objects.all()

    context = {
        'total_active_users': total_active_users,
        'total_pending_users': total_pending_users,
        'notification': notification,
        'contact_messages': contact_messages,

    }

    return render(request, 'admin_dashboard.html', context)

def contact_us(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        message = request.POST['message']
        ContactMessage.objects.create(name=name, email=email, message=message)
        messages.success(request, "Your message has been sent successfully!")
        return redirect('home')
    return render(request, 'about.html')


def manage_users(request):
    pending_users = UserProfile.objects.filter(status='pending')
    approved_users = UserProfile.objects.filter(status='approved')
    return render(request, 'manage_users.html', {
        'pending_users': pending_users,
        'approved_users': approved_users,
    })


# Admin approval
# Admin Approval View
def approve(request, id):
    try:
        usr = User.objects.get(id=id)
        user_profile = UserProfile.objects.get(user=usr)

        # Set the user status to 'approved'
        user_profile.status = 'approved'
        user_profile.save()

        # Generate a random password for the user
        password = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
        usr.set_password(password)
        usr.save()

        # Send approval email with username, member ID, and password
        send_mail(
            'Account Approved',
            f'Your account has been approved.\n\nUsername: {usr.username}\nMember ID: {usr.id}\nPassword: {password}',
            settings.EMAIL_HOST_USER,
            [usr.email]
        )

        return redirect('admin_dashboard')
    except User.DoesNotExist:
        messages.error(request, "User not found.")
        return redirect('admin_dashboard')


# Admin disapproval
def disapprove(request, id):
    usr = User.objects.get(id=id)
    usr.delete()

    send_mail(
        'Account Disapproved',
        f'Your account has been disapproved.',
        settings.EMAIL_HOST_USER,
        [usr.email]
    )
    messages.info(request, "User disapproved and email sent.")
    return redirect('admin_dashboard')

def delete_user(request, user_id):
    user_profile = get_object_or_404(UserProfile, user__id=user_id)

    # Delete associated user profile
    user_profile.delete()

    # Also delete the associated user from the User model
    user_profile.user.delete()

    messages.success(request, 'User profile deleted successfully!')
    return redirect('admin_dashboard')
# Show User Details (For Viewing/Editing Details)

from datetime import date

def is_package_expired(expiry_date):
    return expiry_date <= date.today()

from datetime import timedelta
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import UserProfile, ChatRequest
from datetime import timedelta
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import UserProfile, ChatRequest,ProfilePicture
from datetime import date
from django.db.models import Prefetch



# Function to check if package is expired
def is_package_expired(expiry_date):
    return expiry_date < date.today()

@login_required
def user_dashboard(request):
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        profile_pictures = ProfilePicture.objects.filter(user_profile=user_profile)


        # Determine opposite gender
        if user_profile.gender == 'male':
            opposite_gender = 'female'
        else:
            opposite_gender = 'male'

        today = timezone.now().date()

        # Check if it's the user's first login after payment
        if user_profile.has_paid and user_profile.package and not user_profile.package_active_message_shown:
            user_profile.package_active_message_shown = True
            user_profile.save()

        # Redirect if not paid
        if not user_profile.has_paid:
            return redirect('payment')

        # Handle expiration warning
        if user_profile.package:
            expiry_date = user_profile.expiry_date
            if is_package_expired(expiry_date):
                return redirect('payment')

            if expiry_date - timedelta(days=7) <= date.today():
                user_profile.expiry_warning = True
            else:
                user_profile.expiry_warning = False

        # Chat Requests
        sent_chat_requests = ChatRequest.objects.filter(sender=request.user, is_active=True)
        received_chat_requests = ChatRequest.objects.filter(receiver=request.user, is_active=True)

        new_visits_today_count = ProfileVisit.objects.filter(
            viewed=request.user,
            timestamp__date=timezone.now().date()
        ).count()
         # Count new chat requests
        new_chat_count = ChatRequest.objects.filter(receiver=request.user, is_active=True, is_seen=False).count()
        chat_requests_unseen = ChatRequest.objects.filter(receiver=request.user, is_seen=False)

        # Suggested users: opposite gender, paid, not expired, not current user
        opposite_gender = 'Female' if user_profile.gender == 'Male' else 'Male'

        # Prefetch profile pictures for suggested users
        picture_prefetch = Prefetch(
            'profilepicture_set',
            queryset=ProfilePicture.objects.order_by('id'),
            to_attr='pictures'  # you can now access `profile.pictures`
        )
        # Suggested users: paid, not expired, opposite gender, not the current user
        suggested_users = UserProfile.objects.filter(
                has_paid=True,
                expiry_date__gte=today,
                gender=opposite_gender,
                user__isnull=False
            ).exclude(user=request.user).prefetch_related(picture_prefetch)[:6]

        for user in suggested_users:
            profile_pic = ProfilePicture.objects.filter(user_profile=user).first()
            user.profile_pic_url = profile_pic.image.url if profile_pic else None


        return render(request, 'user_dashboard.html', {
            'user_profile': user_profile,
            'sent_chat_requests': sent_chat_requests,
            'received_chat_requests': received_chat_requests,
            'today': date.today(),
            'suggested_users': suggested_users,
            'new_chat_count': new_chat_count,  # 👈 pass it to template
            'chat_requests_unseen': chat_requests_unseen,
            'profile_pictures': profile_pictures,
            'new_visits_today_count': new_visits_today_count,


        })

    except UserProfile.DoesNotExist:
        return redirect('home')
    
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import JsonResponse
from .models import Package, UserProfile

def renew_package(request):
    if not request.user.is_authenticated:
        return redirect('login')

    try:
        profile = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        messages.error(request, "User profile not found.")
        return redirect('home')

    packages = Package.objects.all()
    package = None  # Initialize package as None for GET requests

    if request.method == 'POST':
        package_id = request.POST.get('package_id')
        payment_method = request.POST.get('payment')  # Use 'payment' instead of 'payment_method'

        # Ensure a payment method is selected
        if not payment_method:
            messages.error(request, "Please select a payment method.")
            return redirect('renew_package')

        # Fetch the selected package or return error
        package = get_object_or_404(Package, id=package_id)

        # Handle card payment details if chosen
        if payment_method == "Card":
            card_number = request.POST.get('card_number')
            expiry_date = request.POST.get('expiry_date')
            cvv = request.POST.get('cvv')

            # Validate card details (e.g., check length of card number, etc.)
            if not (card_number and expiry_date and cvv):
                messages.error(request, "Please enter valid card details.")
                return redirect('renew_package')

            # Simulate the card payment processing (replace with actual payment logic)
            # If using a payment gateway, add logic here

        # Call your method to assign the selected package to the user
        assign_package_to_user(profile, package)

        # Clear session data after payment
        del request.session['selected_package_id']
        
        # Send a success response for frontend to handle modal
        return JsonResponse({'success': True})

    return render(request, 'renew_package.html', {'packages': packages, 'package': package})



from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.models import User
from .models import ChatRequest
from django.contrib import messages

def send_chat_request(request, receiver_id):
    sender = request.user
    receiver = get_object_or_404(User, id=receiver_id)

    # Check if any request already exists between sender and receiver
    existing = ChatRequest.objects.filter(
        sender=sender, receiver=receiver, status="pending"
    ) | ChatRequest.objects.filter(
        sender=receiver, receiver=sender, status="pending"
    )

    if existing.exists():
        messages.warning(request, "A chat request already exists.")
        return redirect('profile', receiver_id)

    # Create chat request
    ChatRequest.objects.create(sender=sender, receiver=receiver, status="pending")
    messages.success(request, "Chat request sent.")
    return redirect('profile', receiver_id)

def accept_chat_request(request, chat_id):
    chat = get_object_or_404(ChatRequest, id=chat_id, receiver=request.user)
    chat.status = "accepted"
    chat.save()
    return redirect('chat_list')

def decline_chat_request(request, chat_id):
    chat = get_object_or_404(ChatRequest, id=chat_id, receiver=request.user)
    chat.delete()
    return redirect('chat_list')



from django.shortcuts import render
from .models import ChatRequest
from django.shortcuts import render
from .models import ChatRequest

def chat_list(request):
    user = request.user

    # Mark received unseen chat requests as seen
    ChatRequest.objects.filter(receiver=user, is_seen=False).update(is_seen=True)

    # Get all chat requests
    sent_chats_all = ChatRequest.objects.filter(sender=user, status="pending")
    received_chats_all = ChatRequest.objects.filter(receiver=user, status="pending")

    accepted_chats_sent = ChatRequest.objects.filter(sender=user, status="accepted")
    accepted_chats_received = ChatRequest.objects.filter(receiver=user, status="accepted")

    # Combine accepted chats and make them unique
    chat_pairs = set()
    unique_active_chats = []

    for chat in list(accepted_chats_sent) + list(accepted_chats_received):
        pair = tuple(sorted([chat.sender.id, chat.receiver.id]))
        if pair not in chat_pairs:
            chat_pairs.add(pair)
            unique_active_chats.append(chat)

    # Get user IDs involved in active chats
    active_chat_user_ids = {chat.sender.id for chat in unique_active_chats} | {chat.receiver.id for chat in unique_active_chats}

    # Filter out users already in active chats from sent and received
    sent_chats_unique = []
    seen_ids = set()
    for chat in sent_chats_all:
        if chat.receiver.id not in active_chat_user_ids and chat.receiver.id not in seen_ids:
            sent_chats_unique.append(chat)
            seen_ids.add(chat.receiver.id)

    received_chats_unique = []
    seen_ids = set()
    for chat in received_chats_all:
        if chat.sender.id not in active_chat_user_ids and chat.sender.id not in seen_ids:
            received_chats_unique.append(chat)
            seen_ids.add(chat.sender.id)

    context = {
        "sent_chats": sent_chats_unique,
        "received_chats": received_chats_unique,
        "active_chats": unique_active_chats,
    }

    return render(request, "chat_list.html", context)



@login_required
def chat_messages(request, chat_id):
    chat_request = get_object_or_404(ChatRequest, id=chat_id)

    if request.user != chat_request.sender and request.user != chat_request.receiver:
        return redirect('user_dashboard')

    # ✅ Mark chat as seen by the receiver
    if chat_request.receiver == request.user and not chat_request.is_seen:
        chat_request.is_seen = True
        chat_request.save()

    messages = Message.objects.filter(chat=chat_request).order_by('timestamp')

    return render(request, 'chat_messages.html', {
        'chat_request': chat_request,
        'messages': messages,
    })



# views.py

from django.shortcuts import render, get_object_or_404, redirect
from .models import ChatRequest, Message
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.utils import timezone

@login_required
def start_chat(request, user_id):
    receiver = get_object_or_404(User, id=user_id)
    chat_request, created = ChatRequest.objects.get_or_create(
        sender=request.user, 
        receiver=receiver,
        is_active=True,
        status='pending'
    )
    return redirect('chat_view', chat_id=chat_request.id)
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import ChatRequest, Message

@login_required
def chat_view(request, chat_id):
    # Fetch the chat request or return 404 if not found
    chat_request = get_object_or_404(ChatRequest, id=chat_id)

    # Ensure that only participants can access the chat
    if request.user != chat_request.sender and request.user != chat_request.receiver:
        return redirect('user_dashboard')  # Redirect unauthorized users

    if request.method == 'POST':
        action = request.POST.get('action')

        # Handle accept and reject actions
        if action == 'accept':
            if request.user == chat_request.receiver and chat_request.status == 'pending':
                chat_request.status = 'accepted'
                chat_request.save()
        elif action == 'reject':
            if request.user == chat_request.receiver and chat_request.status == 'pending':
                chat_request.status = 'rejected'
                chat_request.save()
                return redirect('user_dashboard')  # Redirect after rejection
        elif 'message' in request.POST and chat_request.status == 'accepted':
            # Handle sending a message
            message_text = request.POST.get('message', '').strip()
            if message_text:
                Message.objects.create(
                    chat=chat_request,
                    sender=request.user,
                    text=message_text
                )

    # Fetch all messages for the chat in ascending order by timestamp
    messages = Message.objects.filter(chat=chat_request).order_by('timestamp')
    
    return render(request, 'chat_view.html', {
        'chat_request': chat_request,
        'messages': messages,
    })



@login_required
def send_message(request, chat_id):
    chat_request = get_object_or_404(ChatRequest, id=chat_id)

    if request.method == 'POST':
        message_text = request.POST.get('message')
        if message_text:
            Message.objects.create(chat=chat_request, sender=request.user, text=message_text)

            # ✅ Mark as unseen for the receiver (so badge shows)
            if request.user == chat_request.sender:
                chat_request.is_seen = False
                chat_request.save()
            elif request.user == chat_request.receiver:
                chat_request.is_seen = False
                chat_request.save()

        return redirect('chat_view', chat_id=chat_request.id)
    
from .models import ChatRequest, Message

@login_required
def user_profile(request):
    profile = UserProfile.objects.get(user=request.user)
    profile_pictures = ProfilePicture.objects.filter(user_profile=profile)

    # ✅ Define this for both GET and POST
    new_chat_count = ChatRequest.objects.filter(receiver=request.user, is_active=True, is_seen=False).count()
    chat_requests_unseen = ChatRequest.objects.filter(receiver=request.user, is_seen=False)

    if request.method == 'POST':
        profile.name = request.POST['name']
        profile.age = request.POST['age']
        profile.gender = request.POST['gender']
        profile.height = request.POST['height']
        profile.job_designation = request.POST['job_designation']
        profile.job_place = request.POST['job_place']
        profile.district = request.POST['district']
        profile.email = request.POST['email']
        profile.mobile_number = request.POST['mobile_number']
        profile.religion = request.POST['religion']
        profile.caste = request.POST['caste']
        profile.marriage_level = request.POST['marriage_level']
        profile.mother_name = request.POST['mother_name']
        profile.father_name = request.POST['father_name']
        profile.mother_job = request.POST['mother_job']
        profile.father_job = request.POST['father_job']
        profile.sibling_name = request.POST['sibling_name']
        profile.sibling_status = request.POST['sibling_status']

        if 'profile_pictures1' in request.FILES:
            profile.profile_picture1 = request.FILES['profile_pictures1']

        profile.save()

        # Save additional profile pictures (2–8)
        for i in range(2, 9):
            image = request.FILES.get(f'profile_pictures{i}')
            if image:
                ProfilePicture.objects.create(user_profile=profile, image=image)

        return redirect('user_dashboard')

    # 🔁 Shared context for both GET and POST
    return render(request, 'user_profile.html', {
        'profile': profile,
        'profile_pictures': profile_pictures,
        'new_chat_count': new_chat_count,
        'chat_requests_unseen': chat_requests_unseen,
    })

@login_required
def edit_profile(request):
    # Fetch the logged-in user's profile
    profile = get_object_or_404(UserProfile, user=request.user)

    if request.method == "POST":
        # Manually update each field
        profile.name = request.POST['name']
        profile.age = request.POST['age']
        profile.gender = request.POST['gender']
        profile.height = request.POST['height']
        profile.job_designation = request.POST['job_designation']
        profile.job_place = request.POST['job_place']
        profile.education = request.POST['education']
        profile.district = request.POST['district']
        profile.email = request.POST['email']
        profile.mobile_number = request.POST['mobile_number']
        profile.religion = request.POST['religion']
        profile.caste = request.POST['caste']
        profile.marriage_level = request.POST['marriage_level']
        profile.mother_name = request.POST['mother_name']
        profile.father_name = request.POST['father_name']
        profile.mother_job = request.POST['mother_job']
        profile.father_job = request.POST['father_job']
        profile.sibling_name = request.POST['sibling_name']
        profile.sibling_status = request.POST['sibling_status']

    
        # Save profile pictures (after user_profile is created)
        uploaded_count = 0
        for i in range(1, 9):
            image = request.FILES.get(f'profile_pictures{i}')
            if image:
                ProfilePicture.objects.create(user_profile=user_profile, image=image)
                uploaded_count += 1

        if uploaded_count < 3:
            messages.error(request, "Please upload at least 3 profile pictures.")
            profile.delete()
            return redirect('register')

        profile.save()
        messages.success(request, "Your profile has been updated successfully!")
        return redirect('user_profile')  # Replace with the actual profile view name

    context = {
        'profile': profile,
    }
    return render(request, 'edit_profile.html', context)

@login_required
def user_package(request):
    new_chat_count = ChatRequest.objects.filter(receiver=request.user, is_active=True, is_seen=False).count()
    chat_requests_unseen = ChatRequest.objects.filter(receiver=request.user, is_seen=False)

    try:
        user_profile = UserProfile.objects.get(user=request.user)

        if user_profile.package:
            package = user_profile.package
            context = {
                'package': package,
                'expiry_date': user_profile.expiry_date,
            }
        else:
            context = {
                'package': None,
            }

        available_packages = Package.objects.all()
        context['available_packages'] = available_packages

        # ✅ Add new variables to context
        context['new_chat_count'] = new_chat_count
        context['chat_requests_unseen'] = chat_requests_unseen

        return render(request, 'user_package.html', context)

    except UserProfile.DoesNotExist:
        messages.error(request, "User profile not found. Please contact support.")
        return render(request, 'user_package.html', {
            'package': None,
            'available_packages': [],
            'new_chat_count': new_chat_count,  # ✅ Added here too
            'chat_requests_unseen': chat_requests_unseen
        })

@login_required
def user_settings(request):
    new_chat_count = ChatRequest.objects.filter(receiver=request.user, is_active=True, is_seen=False).count()
    chat_requests_unseen = ChatRequest.objects.filter(receiver=request.user, is_seen=False)

    return render(request, 'user_settings.html', {
        'new_chat_count': new_chat_count,
        'chat_requests_unseen': chat_requests_unseen,
    })


from django.contrib.auth.decorators import login_required
from django.contrib.auth import update_session_auth_hash
from django.shortcuts import render, redirect
import re

@login_required
def password_change(request):
    if request.method == 'POST':
        user = request.user
        current_password = request.POST.get('current_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')

        # Password validation regex: Minimum 6 characters, at least 1 uppercase, 1 lowercase, 1 number, 1 special character
        password_regex = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$'

        if not user.check_password(current_password):
            error_message = "Current password is incorrect."
        elif new_password != confirm_password:
            error_message = "New passwords do not match."
        elif not re.match(password_regex, new_password):
            error_message = "Password must be at least 6 characters long, contain at least 1 uppercase letter, 1 lowercase letter, 1 number, and 1 special character."
        else:
            user.set_password(new_password)
            user.save()

            # Keep the user logged in after password change
            update_session_auth_hash(request, user)

            return redirect('user_settings')

        return render(request, 'password_change.html', {'error_message': error_message})

    return render(request, 'password_change.html')



@login_required
def chat_detail(request, chat_id):
    try:
        # Fetch chat details for the logged-in user
        chat = ChatRequest.objects.get(id=chat_id, sender=request.user)

        # If chat exists, render the details
        return render(request, 'chat_detail.html', {'chat': chat})

    except ChatRequest.DoesNotExist:
        # If the chat doesn't exist or is not related to the current user
        return render(request, 'chat_detail.html', {'error': 'Chat request not found or you are not authorized to view it.'})
from django.urls import path, include

# Show User Details (For Viewing/Editing Details)
@login_required
def user_detail(request, user_id):
    user_profile = get_object_or_404(UserProfile, user__id=user_id)
    package = Package.objects.filter(userprofile=user_profile).first()
    return render(request, 'user_detail.html', {
        'user_profile': user_profile,
        'package': package,
    })

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from .models import UserProfile, Package
from django.utils import timezone
from datetime import timedelta
from django.contrib import messages

# ID Search
def id_search(request):
    if request.method == 'POST':
        member_id = request.POST.get('member_id')
        try:
            user_profile = UserProfile.objects.get(user__id=member_id)
            return render(request, 'search_results.html', {'profiles': [user_profile]})
        except UserProfile.DoesNotExist:
            return render(request, 'search_results.html', {'error': "No user found with the given ID"})
        
    return render(request, 'id_search.html')

    
from django.shortcuts import render, redirect
from django.contrib import messages
from datetime import date, timedelta
from django.utils import timezone
from .models import UserProfile, Package

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import UserProfile, Package
from datetime import date, timedelta
from django.contrib import messages
from django.utils import timezone

@login_required
def payment(request):
    try:
        # Retrieve the user's profile
        user_profile = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        messages.error(request, "User profile not found.")
        return redirect('home')

    # Redirect if the user already has a valid subscription
    if user_profile.has_paid and user_profile.expiry_date and user_profile.expiry_date > date.today():
        return redirect('user_dashboard')

    if request.method == 'POST':
        package_id = request.POST.get('package_id')
        if not package_id:
            messages.error(request, "Please select a package before proceeding.")
            return redirect('payment')

        try:
            # Retrieve the selected package
            package = Package.objects.get(id=package_id)

            # Store package selection in session for cart page
            request.session['selected_package_id'] = package.id

            # Redirect to cart page for payment, passing package_id in the URL
            return redirect('cart', package_id=package.id)

        except Package.DoesNotExist:
            messages.error(request, "The selected package does not exist.")

    # Retrieve available packages for selection
    packages = Package.objects.all()
    return render(request, 'payment.html', {'packages': packages})


@login_required
def cart(request, package_id):
    try:
        user_profile = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        messages.error(request, "User profile not found.")
        return redirect('home')

    # Ensure the selected package ID matches the session
    package_id_session = request.session.get('selected_package_id')
    if not package_id_session or int(package_id) != package_id_session:
        messages.error(request, "Invalid package selected. Please choose a package first.")
        return redirect('payment')

    try:
        package = Package.objects.get(id=package_id)
    except Package.DoesNotExist:
        messages.error(request, "The selected package does not exist.")
        return redirect('payment')

    if request.method == 'POST':
        # Simulate payment process here
        assign_package_to_user(user_profile, package)

        # Clear session data after payment
        del request.session['selected_package_id']
        
        # Send a success response for frontend to handle modal
        return JsonResponse({'success': True})

    return render(request, 'cart.html', {'package': package})




def assign_package_to_user(user_profile, package, payment_date=None):
    """
    Assigns a selected package to the user's profile.
    This will set the expiry date based on the package duration in days.
    """
    # Use the current date if payment_date is not provided
    if payment_date is None:
        payment_date = timezone.now()

    # Calculate the expiry date based on the package duration (in days)
    expiry_date = payment_date + timedelta(days=package.duration)

    # Update the user's profile with the package details
    user_profile.package = package
    user_profile.expiry_date = expiry_date
    user_profile.status = 'approved'  # Automatically update status to 'approved'
    user_profile.has_paid = True  # Mark payment as completed

    # Save the updated profile
    user_profile.save()


# ID Search with Gender-Based Filtering
from django.shortcuts import render
import logging

logger = logging.getLogger(__name__)

def search_member_id(request):
    if request.method == 'POST':
        member_id = request.POST.get('member_id')

        if not member_id:
            return render(request, 'search_member_id.html', {'error': 'Please enter a valid member ID'})

        try:
            # Fetch user profile based on member ID
            user_profile = UserProfile.objects.get(user__id=member_id)
        except UserProfile.DoesNotExist:
            return render(request, 'search_member_id.html', {'error': 'No such profile found with the given Member ID.'})

        # Get the logged-in user's gender
        user_gender = request.user.userprofile.gender

        # Fetch the user profile based on member ID
        user_profile = UserProfile.objects.get(user__id=member_id)
        searched_user_gender = user_profile.gender

        # Fetch active and pending chats
        active_chats = ChatRequest.objects.filter(status='active').values_list('sender_id', 'receiver_id')
        pending_requests = ChatRequest.objects.filter(status='pending').values_list('sender_id', 'receiver_id')

        # Log the user profile information to debug
        logger.debug(f"Found user profile: {user_profile.user.first_name} {user_profile.user.last_name} Gender: {user_profile.gender}")

        return render(request, 'presults.html', {
            'profiles': [user_profile],
            'active_chats': active_chats,
            'pending_requests': pending_requests
        })

    return render(request, 'search_member_id.html')


# Regular Search
# views.py

from datetime import date
from django.shortcuts import render
from .models import UserProfile

def regular_search(request):
    if request.method == 'POST':
        # Retrieve search parameters
        age_min = int(request.POST.get('age_min', 0))
        age_max = int(request.POST.get('age_max', 100))
        caste = request.POST.get('caste', None)
        religion = request.POST.get('religion', None)

        # Get the logged-in user's gender
        user_gender = request.user.userprofile.gender.lower()

        # Build the base query
        filters = {
            'age__gte': age_min,
            'age__lte': age_max,
            'status': 'approved',  # Ensures only approved profiles are considered
            'has_paid': True,  # Ensures only users with an active package are considered
            'expiry_date__gte': date.today()  # Ensures the package is still valid
        }

        # Apply optional filters
        if caste:
            filters['caste'] = caste
        if religion:
            filters['religion'] = religion

        # Apply gender filter: Show only opposite gender profiles
        if user_gender == 'male':
            filters['gender'] = 'female'  # Show female profiles for male users
        elif user_gender == 'female':
            filters['gender'] = 'male'  # Show male profiles for female users

        print(f"Applied Filters: {filters}")  # Debugging
        
        # Fetch filtered profiles
        profiles = UserProfile.objects.filter(**filters)

        # Fetch active and pending chats using the correct field names
        active_chats = ChatRequest.objects.filter(status='active').values_list('sender', 'receiver')
        pending_requests = ChatRequest.objects.filter(status='pending').values_list('sender', 'receiver')

        # If no profiles found, send a message
        if not profiles.exists():
            return render(request, 'presults.html', {
                'message': 'No users found matching your criteria.',
                'active_chats': active_chats,
                'pending_requests': pending_requests
            })

        return render(request, 'presults.html', {
            'profiles': profiles,
            'active_chats': active_chats,
            'pending_requests': pending_requests
        })

    return render(request, 'regular_search.html')

def advanced_search(request):
    if request.method == 'POST':
        # Retrieve search parameters
        age_min = int(request.POST.get('age_min', 0))
        age_max = int(request.POST.get('age_max', 100))
        caste = request.POST.get('caste', None)
        religion = request.POST.get('religion', None)
        marriage_level = request.POST.get('marriage_level', None)
        education = request.POST.get('education', None)
        district = request.POST.get('district', None)
        job = request.POST.get('job', None)

        # Get the logged-in user's gender
        user_profile = UserProfile.objects.get(user=request.user)
        user_gender = request.user.userprofile.gender

        # Build the query dynamically
        filters = {
            'age__gte': age_min,
            'age__lte': age_max,
        }

        if caste:
            filters['caste'] = caste
        if religion:
            filters['religion'] = religion
        if education:
            filters['education'] = education
        if district:
            filters['district'] = district
        if job:
            filters['job_designation'] = job

        # Add gender-based filtering (similar to regular_search)
        if user_gender.lower() == 'male':
            filters['gender'] = 'Female'  # Male should see Female profiles
        elif user_gender.lower() == 'female':
            filters['gender'] = 'Male'  # Female should see Male profiles

        # Apply the filter to the UserProfile model
        profiles = UserProfile.objects.filter(**filters)

        # Fetch active and pending chats
        active_chats = ChatRequest.objects.filter(status='active').values_list('sender', 'receiver')
        pending_requests = ChatRequest.objects.filter(status='pending').values_list('sender', 'receiver')

        # Suggested users (opposite gender)
        opposite_gender = 'Female' if user_profile.gender == 'Male' else 'Female'
        suggested_users = UserProfile.objects.filter(
            gender=opposite_gender,
            has_paid=True,
            user__is_active=True
        ).exclude(user=request.user)[:8]  # Show 8 suggestions
        # Pass profiles to the template
    
        return render(request, 'presults.html', {
            'profiles': profiles,
            'active_chats': active_chats,
            'pending_requests': pending_requests,
            'suggested_users': suggested_users,  # Pass to template

        })

    return render(request, 'advanced_search.html')


from .models import ProfilePicture

@login_required
def visit_profile(request, user_id):
    try:
        profile_user = get_object_or_404(User, id=user_id)
        profile = get_object_or_404(UserProfile, user=profile_user)

        # Track profile visit
        if profile_user != request.user:
            today = timezone.now().date()
            already_visited = ProfileVisit.objects.filter(
                viewer=request.user,
                viewed=profile_user,
                timestamp__date=today
            ).exists()
            if not already_visited:
                ProfileVisit.objects.create(viewer=request.user, viewed=profile_user)

        # Get profile picture
        profile_pic = ProfilePicture.objects.filter(user_profile=profile).first()

        return render(request, 'profile_view.html', {
            'profile': profile,
            'profile_pic': profile_pic,
        })

    except UserProfile.DoesNotExist:
        return render(request, 'profile_view.html', {'error': "Profile not found"})



from django.shortcuts import render, redirect, get_object_or_404
from .models import ChatRequest, Message
from django.contrib.auth.models import User

def chat_request(request, receiver_id):
    if request.method == 'POST':
        sender = request.user
        receiver = get_object_or_404(User, id=receiver_id)

        # Create a new ChatRequest
        chat_request = ChatRequest.objects.create(
            sender=sender,
            receiver=receiver,
            is_active=True,
            status='pending'  # Default to 'pending' status
        )

        # Create a Message for the chat request
        message_text = request.POST.get('message', '')
        if message_text:
            Message.objects.create(
                chat=chat_request,
                sender=sender,
                text=message_text
            )

        # Redirect to a success page or the chat page
        return redirect('user_dashboard')  # Adjust as per your URL name for the chat page

    return render(request, 'chat_request.html')



from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import Q
from .models import UserProfile, ChatRequest, ProfileVisit

@login_required
def profile(request, user_id):
    profile_user = get_object_or_404(User, id=user_id)
    profile = get_object_or_404(UserProfile, user=profile_user)

    if profile_user != request.user:
        today = timezone.now().date()
        already_visited = ProfileVisit.objects.filter(
            viewer=request.user,
            viewed=profile_user,
            timestamp__date=today
        ).exists()

        if not already_visited:
            ProfileVisit.objects.create(viewer=request.user, viewed=profile_user)
            print(f"✅ Visit saved: {request.user} visited {profile_user}")
        else:
            print(f"🔁 Already visited today: {request.user} → {profile_user}")
    else:
        print("⚠️ User visited own profile — skipping.")

    existing_chat = ChatRequest.objects.filter(
        Q(sender=request.user, receiver=profile_user) |
        Q(sender=profile_user, receiver=request.user),
        status="pending"
    ).first()

    return render(request, 'profile_view.html', {
        'profile': profile,
        'existing_chat': existing_chat,
    })

from .models import ProfilePicture
from collections import defaultdict
from datetime import date

from datetime import date
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from .models import ProfileVisit, ProfilePicture, UserProfile

@login_required
def profile_visitors(request):
    visits = ProfileVisit.objects.filter(viewed=request.user).order_by('-timestamp')

    unique_visits = {}
    seen_today = set()

    for visit in visits:
        viewer_id = visit.viewer.id
        visit_day = visit.timestamp.date()

        key = (viewer_id, visit_day)
        if key not in seen_today:
            seen_today.add(key)
            try:
                user_profile = visit.viewer.userprofile
                profile_pic = ProfilePicture.objects.filter(user_profile=user_profile).first()
                visit.viewer.profile_pic_url = profile_pic.image.url if profile_pic else None
            except UserProfile.DoesNotExist:
                visit.viewer.profile_pic_url = None
            unique_visits[key] = visit

    # ✅ This line is necessary for the navbar badge
    new_visits_today_count = ProfileVisit.objects.filter(
        viewed=request.user,
        timestamp__date=date.today()
    ).count()

    return render(request, 'profile_visitors.html', {
        'visits': unique_visits.values(),
        'new_visits_today_count': new_visits_today_count  # ✅ pass to base.html
    })


from django.shortcuts import redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import UserProfile

@login_required
def block_user(request, user_id):
    blocker = get_object_or_404(UserProfile, user=request.user)  # Current user
    blockee = get_object_or_404(UserProfile, user__id=user_id)  # User to block

    if blocker.block_user(blockee):  # Call the model method
        messages.success(request, f"You have blocked {blockee.user.username}.")
    else:
        messages.warning(request, "User is already blocked or you can't block yourself.")

    return redirect('user_dashboard')  # Redirect to a relevant page



def about(request):
    return render(request, 'about.html')

from django.contrib.auth.decorators import login_required

@login_required
def about_us(request):
    new_chat_count = ChatRequest.objects.filter(receiver=request.user, is_active=True, is_seen=False).count()
    chat_requests_unseen = ChatRequest.objects.filter(receiver=request.user, is_seen=False)

    return render(request, 'about_us.html', {
        'new_chat_count': new_chat_count,
        'chat_requests_unseen': chat_requests_unseen,
    })


def matrimony_package_list(request):
    packages = Package.objects.all()  # Retrieve all the packages
    return render(request, 'matrimony_package_list.html', {'packages': packages})

def package_detail(request, id):
    package = get_object_or_404(Package, pk=id)
    return render(request, 'package_detail.html', {'package': package})

from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages

def delete_package(request, id):
    if request.method == 'POST':
        package = get_object_or_404(Package, pk=id)
        package.delete()
        messages.success(request, f"Package '{package.name}' deleted successfully!")
    return redirect('matrimony_package_list')




    
from django.shortcuts import render, redirect
from .models import Package

def add_matrimony_package(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        price = request.POST.get('price')
        duration = request.POST.get('duration')
        description = request.POST.get('description')
        image = request.FILES.get('image')
        
        if name and price and duration and image:
            # Create and save the new package
            package = Package.objects.create(
                name=name,
                price=price,
                duration=duration,
                description=description,
                image=image
            )
            return redirect('matrimony_package_list')  # Redirect to the package list after successful save

    return render(request, 'add_matrimony_package.html')

from django.shortcuts import render, get_object_or_404, redirect
from .models import Package

def edit_package(request, id):
    package = get_object_or_404(Package, pk=id)

    if request.method == 'POST':
        # Get the data from the POST request
        package.name = request.POST.get('name')
        package.price = request.POST.get('price')
        package.duration = request.POST.get('duration')
        package.description = request.POST.get('description')
        
        # Handle image if provided
        if request.FILES.get('image'):
            package.image = request.FILES.get('image')

        package.save()  # Save the updated package details
        
        return redirect('matrimony_package_list')  # Redirect to the package list after update
    
    return render(request, 'edit_package.html', {'package': package})

@login_required
def view_active_users(request):
    # Fetch active users with valid packages
    active_users = UserProfile.objects.filter(
        status='approved',
        expiry_date__gte=datetime.now()
    ).select_related('package')  # Adjust if package relation is different

    context = {
        'active_users': active_users,
    }
    return render(request, 'view_active_users.html', context)

def get_new_visits_count(request):
    return ProfileVisit.objects.filter(
        viewed=request.user,
        timestamp__date=timezone.now().date()
    ).count()
