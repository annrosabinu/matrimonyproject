from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login_user/', views.login_user, name='login_user'),
    path('loginauth/', views.loginauth, name='loginauth'),    
    path('logout/', views.logout, name='logout'),
    path('register/', views.register, name='register'),
    path('about/', views.about, name='about'),  # Add this line for the About page
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('manage-users/', views.manage_users, name='manage_users'),
    path('approve/<int:id>/', views.approve, name='approve'),
    path('disapprove/<int:id>/', views.disapprove, name='disapprove'),
    path('delete_user/<int:user_id>/', views.delete_user, name='delete_user'),
    path('id_search/',views.id_search, name='id_search'),
    path('user_detail/<int:user_id>/', views.user_detail, name='user_detail'),
    path('matrimony_package_list/', views.matrimony_package_list, name='matrimony_package_list'),
    path('add_matrimony_package/', views.add_matrimony_package, name='add_matrimony_package'),
    path('edit-package/<int:id>/', views.edit_package, name='edit_package'),
    path('package_detail/<int:id>/', views.package_detail, name='package_detail'),  # Add this line
    path('delete_package/<int:id>/', views.delete_package, name='delete_package'),
    path('view-active-users/', views.view_active_users, name='view_active_users'),
    path('user_dashboard/', views.user_dashboard, name='user_dashboard'),
    path('user_profile/', views.user_profile, name='user_profile'),
    path('edit_profile/', views.edit_profile, name='edit_profile'),
    path('package/', views.user_package, name='user_package'),
    path('settings/', views.user_settings, name='user_settings'),
    path('change-password/', views.password_change, name='password_change'),
    path('payment/', views.payment, name='payment'),
    path('cart/<int:package_id>/', views.cart, name='cart'),
    path('renew_package/', views.renew_package, name='renew_package'),
    path('chat_detail/<int:chat_id>/', views.chat_detail, name='chat_detail'),
    path('profile/<int:user_id>/', views.profile, name='profile'),
    path('chat_request/<int:receiver_id>/', views.chat_request, name='chat_request'),
    # path('search/', views.search_users, name='search_users'),
    path('search_member_id/', views.search_member_id, name='search_member_id'),
    path('search/regular/', views.regular_search, name='regular_search'),
    path('search/advanced/', views.advanced_search, name='advanced_search'),
    path('visit_profile/<int:user_id>/', views.visit_profile, name='visit_profile'),
    # path('search_users/', views.search_users, name='search_users'),  # Search users
    path('chat_request/<int:receiver_id>/', views.send_chat_request, name='chat_request'),
    # path('chat/<int:chat_id>/', views.chat_request_detail, name='chat_request_detail'),
    path('chat/accept/<int:chat_id>/', views.accept_chat_request, name='accept_chat_request'),
    path('chat/decline/<int:chat_id>/', views.decline_chat_request, name='decline_chat_request'),
    path('profile_visitors/', views.profile_visitors, name='profile_visitors'),
    path('block_user/<int:user_id>/', views.block_user, name='block_user'),
    path('chats/', views.chat_list, name='chat_list'),
    path('chat/<int:chat_id>/', views.chat_messages, name='chat_messages'),
    path('chat/start/<int:user_id>/', views.start_chat, name='start_chat'),
    path('chat/<int:chat_id>/', views.chat_view, name='chat_view'),
    path('chat/send_message/<int:chat_id>/', views.send_message, name='send_message'),
    # path('request_chat/<int:user_id>/', views.request_chat, name='request_chat'),  # Request chat with a user
    path('block_user/<int:user_id>/', views.block_user, name='block_user'),
    path('contact_us/', views.contact_us, name='contact_us'),
    path('about_us/', views.about_us, name='about_us'),

    

]
